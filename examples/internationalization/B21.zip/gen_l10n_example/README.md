Commands:

```sh
flutter gen-l10n
```